// Provides a Tar interface with methods to create and extract tar archives

package tar
