// Package constants provides constants used across s2i.
package constants
