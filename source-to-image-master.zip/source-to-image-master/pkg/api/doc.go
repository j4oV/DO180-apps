// Package api provides types used for processing s2i builds.
package api
