// implements an interface around providing ignore file capabillities like seen in .dockerignore or .gitignore

package ignore
