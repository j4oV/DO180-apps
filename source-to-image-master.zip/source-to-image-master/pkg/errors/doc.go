// Contains error definitions for errors thrown throughout the STI code

package errors
