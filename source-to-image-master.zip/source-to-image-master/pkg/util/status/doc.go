// Package status provides functionality to update the status of a build with
// information about failures that occurred.
package status
