// Script installer for STI. Implements a script downloader and installer.

package scripts
