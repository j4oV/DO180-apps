// Package version supplies version information for S2I collected at build time.
package version
