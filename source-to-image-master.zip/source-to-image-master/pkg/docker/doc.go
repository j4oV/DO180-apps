// Package docker implements Docker operations used by the S2I builder and
// executor.
package docker
