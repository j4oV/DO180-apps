// Package docker contains docker-related integration tests for S2I.
package docker
