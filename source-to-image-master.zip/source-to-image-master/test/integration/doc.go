// Package integration contains integration tests for S2I.
package integration
