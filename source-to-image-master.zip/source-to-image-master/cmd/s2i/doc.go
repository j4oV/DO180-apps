// Main S2I command. Parses command line arguments, builds config object,
// and launches the proper handler.

package main
